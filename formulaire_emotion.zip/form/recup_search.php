<?php

			   	$base = mysqli_connect('localhost', 'root', '','emotion');

			    $ville=$_POST["ville"];
				$type_vehicule=$_POST["type_vehicule"];
				$disponibilité=$_POST["disponibilite"];


			    $sql = "INSERT INTO vehicule (id_vehicule, ville, type_vehicule, disponibilité) VALUES(NULL,'$ville', '$type_vehicule', '$disponibilité')";

			    mysqli_query ($base,$sql) or die ('Erreur SQL !' .$sql.'</br />'. mysqli_error($base));

			    mysqli_close($base);

			    echo "La table a bien été ajoutée!";

?>