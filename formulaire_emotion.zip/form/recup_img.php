<?php

		$base = mysqli_connect('localhost', 'root', '','emotion');

 		$ville=$_POST["ville"];
		$type_vehicule=$_POST["type_vehicule"];
		$prix_achat=$_POST["prix_achat"];
		$couleur=$_POST["couleur"];
		$disponibilité=$_POST["disponibilité"];

		$sql = 



?>