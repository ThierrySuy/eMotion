<?php
// on test si le visiteur a soumis le formulaire de connexion
session_start();

define('ADMINUSER', 'email pour smtp');
define('ADMINPASS', 'mdp a definir');
if (isset($_POST['connexion']) && $_POST['connexion'] == 'Connexion') {
    if ((isset($_POST['mail']) && !empty($_POST['mail'])) && (isset($_POST['mdp']) && !empty($_POST['mdp']))) {

        $base = @mysql_connect('localhost', 'root', '');
        mysql_select_db('emotion', $base);

        // on teste si dans la base de donnée le mail et le mot de passe correspondent
        $sql = 'SELECT count(*) FROM client WHERE clientmail="' . $_POST['mail'] . '" AND clientmdp="' . $_POST['mdp'] . '"';
        $req = mysql_query($sql) or die('Erreur SQL !<br />' . $sql . '<br />' . mysql_error());
        $data = mysql_fetch_array($req);

        mysql_free_result($req);
        mysql_close();

        // si on obtient une réponse, alors l'utilisateur est un membre
        if ($data[0] == 1 && $_POST['mail'] != ADMINUSER) {
            session_start();
            $_SESSION['mail'] = $_POST['mail'];
            $_SESSION['log'] = 1;
            header('Location: page de redirecton.php');
            exit();
        }

        if ($data[0] == 1 && ADMINUSER == $_POST['mail'] && ADMINPASS == $_POST['mdp']) {
            session_start();
            $_SESSION['mail'] = $_POST['mail'];
            $_SESSION['log'] = 1;
            header('Location: page daccueil .php');
            exit();
        }


        // si on ne trouve aucune réponse, l'utilisateur s'est trompé soit dans son email, soit dans son mot de passe
        //où l'utilisateur n'a pas de compte client
        elseif ($data[0] == 0) {
            $erreur = 'Compte non reconnu.';
        } else {

            $erreur = 'Problème dans la base de données : plusieurs membres ont les mêmes identifiants de connexion.';
        }
    } else {
        $erreur = 'Au moins un des champs est vide.';
    }
}
?>
<html>
    <link rel="stylesheet" href="style.css" type="text/css" />
    <head>
        <meta charset="utf-8" />
        <title>Accueil</title>
    </head>

    <body>
        <div id="header">
            <div id="content">
                <label>eMotion : Location de véhicules éléctriques</label>
            </div>
        </div>

    <center>

        <div id="body">
            <div id="content">
                <form action="index.php" method="post">
                    <table align="center">
                        <tr>
                            <td>Email : <input type="email" name="mail" value="<?php if (isset($_POST['mail'])) echo htmlentities(trim($_POST['mail'])); ?>"><br /></td>
                        </tr>
                        <tr>
                            <td>Mot de passe : <input type="password" name="mdp" value="<?php if (isset($_POST['mdp'])) echo htmlentities(trim($_POST['pass'])); ?>"><br /></td>
                        </tr>
                        <tr>
                            <td><button type="submit" name="connexion" value="Connexion">Connexion</button></td>
                        </tr>

                </form>
            </div>
        </div>

    </center>
    <tr>
        <td><a href="inscription.php">S'inscrire</a></td>
    </tr>
</table>
<?php
if (isset($erreur))
    echo '<br /><br />', $erreur;
?>
</body>
</html>
