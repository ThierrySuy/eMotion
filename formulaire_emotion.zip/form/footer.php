



<body><center>


<div>
<a href="https://facebook.com"> <img src="images/fbicon.png" border="0" alt="fb" width="100" height="100"> </a>
<a href="https://instagram.com"> <img src="images/ig.jpg" border="0" alt="fb" width="100" height="100"> </a>
</div>

</br>

<p>Direction de l’information légale et administrative & Mentions légales</p>

</center></body>
</html>
