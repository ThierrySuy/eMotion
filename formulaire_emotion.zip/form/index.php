<!Doctype html>
<html>
    <title>Index</title>

  <?php include('/header.php'); ?>


    <body>

   

    <div class="row">
    
    <nav class="navbar navbar-inverse col-md-12">
    <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class="active"><a href="index.php">Home</a></li>
      <li >
        <div class="form-group">
  <form action="/recup_search.php" method="post" id="choix">

  <select class="form-control connard" id="ville">
    <option>Ville</option>
    <option>Paris</option>
    <option>Lyon</option>
    <option>Lille</option>
  </select>
</div>
        <li>
        <div class="form-group col-md-4">

 <input class="connard" type="text" id="datepicker" />
  
</div>
        <li><div class="form-group">
  
  <select class="form-control connard" id="type">
    <option>Type Véhicule</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
  </select>

</div>


        </ul>

      </li>
      <li><button type="submit" class="btn btn-default connard">Submit</button></li>
  </form>
    </ul>
  </div>

</nav>
</div> 


</br>
</br>
<div>
<?php include('inscription.php') ?> 
</div>
<br>
<br>

<div class="container-fluid col-md-offset-5 col-md-6">
<img class="col-md-2" src="" alt="Hé Hé">
<img class="col-md-2" src="" alt="Hé Hé">
<img class="col-md-2" src="" alt="Hé Hé">
</div>


</body>
<br>
 <div class="col-md-5 col-md-offset-4">  
<?php include('/footer.php'); ?>
</div>
</html>