<!DOCTYPE html>

<!DOCTYPE html>
<html>
<head>

	<title>Recherche</title>

	<?php include('/header.php'); ?>

</head>

<body>

  <form action="/recup_search.php" method="post" id="choix">

	<div class="row">
    <nav class="navbar navbar-inverse col-md-12">
    <div class="container-fluid">
    <ul class="nav navbar-nav">
    <li class="active"><a href="index.php">Home</a></li>

  
    <div class="form-group">

  	<select class="form-control connard" id="ville">

  	<option value="" disabled selected>Choisir une ville..</option>

    <option>Paris</option>
    <option>Lyon</option>
    <option>Lille</option>
  	</select>
	</div>

	<div class="form-group">

  	<select class="form-control connard" id="marque">

  	<option value="" disabled selected>Choisir un modèle..</option>

    <option>BMW</option>
    <option>Mercedes</option>
    <option>Peugeot</option>
    <option>Renault</option>
  	</select>
	</div>

	<div class="form-group">

  	<select class="form-control connard" id="couleur">

  	<option value="" disabled selected>Choisir une couleur..</option>
    
    <option>Noir</option>
    <option>Gris</option>
    <option>Bleu</option>
    <option>Blanc</option>
  	</select>
	</div>


     <li>
     <div class="form-group col-md-4">

	 <input class="connard" type="text" id="datepicker" />

  	</div>


    <li>
    <div class="form-group">
  	<select class="form-control connard" id="type">
    <option>Type Véhicule</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
  	</select>
	</div>

    </ul>

    <li><button type="submit" class="btn btn-default connard">Submit</button></li>

    <li><button type="submit" class="btn btn-default connard">Submit 2</button></li>


  	</form>

    </ul>

  </div>

</nav>

<div class="container-fluid col-md-offset-5 col-md-6">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php// echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php //echo $img;?>" alt="Hé Hé">
<img class="col-md-2" src="<?php// echo $img;?>" alt="Hé Hé">

</div>


</div> 

</body>

</html>